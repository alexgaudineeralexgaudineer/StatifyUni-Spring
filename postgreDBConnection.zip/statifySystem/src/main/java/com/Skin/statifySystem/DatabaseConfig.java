package com.Skin.statifySystem;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
//import jakarta.activation.DataSource;
import javax.sql.DataSource;
import org.postgresql.ds.PGSimpleDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import javax.sql.DataSource;


@Configuration
public class DatabaseConfig {
	
	
    @Bean
    public DataSource dataSource() {
    	final int[] ports = {5433};
        PGSimpleDataSource dataSource = new PGSimpleDataSource();
        dataSource.setURL("jdbc:postgresql://database-1.cqzii83slxrg.us-east-2.rds.amazonaws.com:5433/postgres");
        dataSource.setPortNumbers(ports);
        dataSource.setUser("postgres");
        dataSource.setPassword("gaudineer");
        return dataSource;
    }
	@Bean
	public JdbcTemplate jdbcTemplate(DataSource dataSource) {
	    return new JdbcTemplate((javax.sql.DataSource) dataSource);
	}

}

